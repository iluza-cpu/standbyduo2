# StandBy Duo APK (WebView)

## APK 만드는 법 (택1)
**A. GitHub (PC/폰 브라우저 가능)**
1. 이 폴더 내용 전체를 새 GitHub 저장소(main 브랜치)에 업로드
2. Actions 탭 → "Build APK" 실행(업로드하면 자동 실행)
3. 완료 후 Artifacts 의 `StandByDuo-apk` 다운로드 → 압축 해제 → app-debug.apk 설치
   (설치 시 "출처를 알 수 없는 앱 허용" 필요)

**B. Android Studio** : 이 폴더를 열고 Build > Build APK(s)

## 구조
- app/src/main/assets/index.html : 수정된 StandBy 화면 (수정 후 다시 빌드하면 반영)
- MainActivity.java : https 가상 도메인(https://com.fold8.standbyduo/)으로 페이지를 서비스
  → YouTube 임베드가 요구하는 유효한 Referer/origin 제공 → 오류 153 해결

## 그래도 153 이 나면
MainActivity.APP_HOST 를 본인이 가진 실제 도메인(예: your-name.github.io)으로 바꿔 다시 빌드.
